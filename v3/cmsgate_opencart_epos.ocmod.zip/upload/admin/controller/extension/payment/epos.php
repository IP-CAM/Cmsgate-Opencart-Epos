<?php

use cmsgate_scope_opencart_epos\esas\cmsgate\opencart\AdminControllerExtensionPayment; // patched by scoper
require_once \dirname(__FILE__, 5) . '/system/library/esas/cmsgate/epos/init.php';
class ControllerExtensionPaymentEpos extends AdminControllerExtensionPayment
{
    public function index()
    {
        parent::index();
    }
}
//\class_alias('cmsgate_scope_opencart_epos\\ControllerExtensionPaymentEpos', 'ControllerExtensionPaymentEpos', \false);
