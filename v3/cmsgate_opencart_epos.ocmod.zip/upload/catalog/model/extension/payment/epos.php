<?php

use cmsgate_scope_opencart_epos\esas\cmsgate\opencart\ModelExtensionPayment; // patched by scoper
require_once \dirname(\dirname(\dirname(\dirname(\dirname(__FILE__))))) . '/system/library/esas/cmsgate/epos/init.php';
class ModelExtensionPaymentEpos extends ModelExtensionPayment
{
}