<?php
// Text
$_['heading_title'] = 'Your order has been successfully added to ERIP! ';
