<?php

$_['heading_title'] = 'Epos';

$_['text_epos'] = '<img src="view/image/payment/epos.png" alt="Epos" title="Epos" style="border: 1px solid #EEEEEE;" />';
$_['text_success'] = 'Module settings have been updated!';

$_['text_status'] = 'Status:';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_save'] = 'Save';
$_['text_cancel'] = 'Cancel';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the payment module!';