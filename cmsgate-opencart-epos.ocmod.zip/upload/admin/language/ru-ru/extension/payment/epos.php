<?php
$_['heading_title'] = 'Epos'; //для отображения в админке в таблицу модулей
$_['text_epos'] = '<img src="view/image/payment/epos.png" alt="Расчёт (ЕРИП)" title="Расчёт (ЕРИП)" style="border: 1px solid #EEEEEE;" />';
$_['text_success'] = 'Настройки модуля обновлены!';

$_['text_status'] = 'Статус:';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_save'] = 'Сохранить';
$_['text_cancel'] = 'Отмена';

// Error
$_['error_permission'] = 'Внимание: у вас нет прав для редактирования модуля оплаты!';